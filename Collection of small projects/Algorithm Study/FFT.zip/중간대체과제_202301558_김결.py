import numpy as np
import matplotlib.pyplot as plt

# # dft 1: 나대지 말고 신호 한개 먼저 해보자
#
# # 샘플 개수 정하기
# sample = 32
# # 신호 정하기(진동수 f)
# f = 8
# # 추가사항! f=8은 신호값이 아니라고 한다고 한다.(x[n] 따로 만들어줘야한다는 뜻) e^어쩌고 에서 -j만 j로 바꿔주면 됨.
# x = np.exp(1j * 2 * np.pi * f / sample * np.arange(sample))
# # N개의 신호에 대해 e^어쩌고 곱해주고 배열에 넣기(for 0~sample-1)
# # for 루프에서 더하기 연산도 넣는게 좋을것 같다.
#
# # X = np.array([]) # 결과 저장할 배열 하나 생성 => 이렇게 하면 인덱싱 에러가 뜬다
# X = np.zeros(sample, dtype=complex) # 챗지피티가... 도와줬다...
# for k in range(sample): # 샘플 개수 만큼 k를 구한다
#     s = np.exp(-1j * 2 * np.pi * k / sample * np.arange(sample))
#     X[k] = np.sum(x * s)
#     # 시그마 내의 식 완성
# # 출력
# plt.plot(np.abs(X))
# plt.title("DFS")
# plt.xlabel("f")
# plt.ylabel("Magnitude")
# plt.grid(True)
# plt.show()


# # dft 2: 5개의 신호
# # 샘플 개수 정하기
# sample = 128
# # 선택할 주파수들 설정
# f = [1, 4, 55, 89, 100]
#
# x = np.zeros(sample, dtype=complex)
# for fre in f:
#     x += np.exp(1j * 2 * np.pi * fre / sample * np.arange(sample))
#
# # 주파수값 넣을 X
# X = np.zeros(sample, dtype=complex)
# for k in range(sample):
#     s = np.exp(-1j * 2 * np.pi * k / sample * np.arange(sample))
#     X[k] = np.sum(x * s)
#
# plt.plot(np.abs(X))
# plt.title('DFT')
# plt.xlabel('f')
# plt.ylabel('Magnitude')
# plt.grid(True)
# plt.legend()
# plt.show()


# dft 3: 일반적인 신호

# 신호 배열로 받기... 보다는 def 해서 x 리스트를 받자
def DFT(x):
# 신호 길이? 사이즈 저장
    N = np.size(x)
# 결과 배열 초기화
# 위랑 똑같이 했다가 망해서 챗지피티가 도와줬다.
# 길이가 N인, 복소수(complex128) 배열 초기화
    X = np.zeros((N,),dtype=np.complex128)
# 결과 배열 X의 인덱스 k를 N번 돌려
    for k in range(0,N):
# 신호 배열 x의 인덱스 n을 N번 돌려 -> 이상한 e^어쩌고 곱해주기
        for n in range(0, N):
            X[k] += x[n] * np.exp(-1j * 2 * np.pi * k * n / N)
    return X / N # 정규화를 하래...
# 출력... 은 챗치피티가 도와주었다...
# 사인 파형 신호 생성
t = np.linspace(0, 1, 256, endpoint=False)  # 1초 동안의 시간 축, 그리고 256Hz로 샘플링하는 법이래
freq = 5  # 주파수 5Hz로 설정 -> 그래프가 5에서 튀어야 함
x = np.sin(2 * np.pi * freq * t)  # t에서의 sin
#
# # DFT 수행
# X = DFT(x)
#
# # # DFT 결과 시각화
# plt.figure(figsize=(12, 6))
# plt.subplot(121) # subplot(행 열 그래프위치) 해서 노나그릴때 이렇게 한대
# plt.plot(t, x)
# plt.title('Original Signal (Time Domain)')
# plt.xlabel('Time (seconds)')
# #
# # plt.subplot(122)
# # plt.plot(np.abs(X))
# # plt.title('Magnitude Spectrum (Frequency Domain)')
# # plt.xlabel('Frequency Index')
# # plt.ylabel('Magnitude')
# #
# # plt.tight_layout()
# # plt.show()
#
# # stem을 써서 이산적으로 그려보기
# plt.subplot(122)
# plt.stem(np.abs(X), basefmt="none") # 얘가 이산 그래프 그려주는 친구, 아래 이상한 선이 떠서 basefmt 0으로 해줬다
# plt.title('Discrete Magnitude Spectrum')
# plt.xlabel('Frequency Index')
# plt.ylabel('Magnitude')
# plt.grid(True)
#
# plt.tight_layout()
# plt.show()

# FFT

# x[n]을 받아오는 def FFT(x)
def FFT(x):
# N, 신호 x의 길이
    N = np.size(x)
# N 이 1보다 작거나 같으면 리턴
    if N<=1:
        return x
# 짝홀수 재귀호출
    e = FFT(x[0::2]) # 0부터 2 간격으로
    o = FFT(x[1::2]) # 1부터 2 간격으로
# 홀수에 이상한 그거 곱해줘야됨 -> 배열에 보관
    o_2 = []
    for k in range(N//2): # N/2 하면 이상한 결과 나옴... 정수부만 남겨야 한다고 챗지피티가 고쳐주었다
        strange = -1j * 2 * np.pi * k / N
        o_2.append(np.exp(strange) * o[k])
# X배열의 인덱스 k에 대한 루프를 N/2까지 돌려 -> 짝홀수 더하고 빼
    X = np.zeros((N,), dtype=np.complex128)
    for k in range(N // 2):
        X[k] = e[k] + o_2[k]
        X[k + N // 2] = e[k] - o_2[k]

# 아 맞다 홀수는 이상한거 곱해진 배열로 돌려야 함 이상한거 나와

# 더해 -> 더하긴 뭘 더해 다 들어가 있구만
# 리턴해
    return X

# # 테스트1 : 위에 썼던 케이스 그대로
# N = 256  # 샘플 수
# t = np.linspace(0, 1, N, endpoint=False)
# freq = 5  # 주파수 5Hz
# x = np.sin(2 * np.pi * freq * t)
# # 대칭성을 잘 보고 싶다고 했더니 챗지피티가 디벨롭 시켜줬다

# 테스트 2 : 네개의 사인파
time = np.linspace(0, 1, 200, endpoint=False)
N=np.size(time)
# s1 = 2*np.sin(20*np.pi*time)
# s2 = np.sin(40*np.pi*time)
# s3 = 0.5*np.sin(60*np.pi*time)
# s4 = 1.5*np.sin(80*np.pi*time)
#
# s=s1+s2+s3+s4

# # 테스트 3: 사인+코사인
# s1 = 3*np.cos(40*np.pi*time)
# s2 = np.sin(100*np.pi*time)
# s=s1+s2

# # 테스트 4: 4차 함수 + 사인
# N = 1024
# time = np.linspace(0, 1, N, endpoint=False)
# s1 = np.sin(40*np.pi*time)
# s = time**4 - 2*time**3 + time + s1

# 테스트 5: 사인*코사인
# s1 = 5*np.cos(25*np.pi*time)
# s2 = 2*np.sin(10*np.pi*time)
# s=s1*s2
#
# X = FFT(s)
# fre = np.fft.fftfreq(N, time[1]-time[0])
# mask = fre > 0 # 이렇게 해서 양의 주파수 대역만 표시한대
# plt.figure(figsize=(12, 6))
#
# plt.subplot(121) # subplot(행 열 그래프위치) 해서 노나그릴때 이렇게 한대
# plt.plot(time, s)
# plt.title('Original Signal (Time Domain)')
# plt.xlabel('Time (seconds)')
#
# plt.subplot(122)
# plt.stem(fre[mask], np.abs(X[mask]), basefmt='none')
# # f축 주파수값을 매핑하기 위해서 파이썬이 제공하는 fft를 쓰라고 챗지피티가 알려줬다. 제공하는 fft가...있어?,,,.
# plt.title('Discrete Magnitude Spectrum (Frequency Domain)')
# plt.xlabel('Frequency [Hz]')
# plt.ylabel('Magnitude')
# plt.grid(True)
#
# plt.tight_layout()
# plt.show()


# 성능 테스트

import time

# DFT
#
# input = 2**np.array(list(range(1, 14)))
# dft_time = []
#
# for size in input:
#     x = np.random.random(size)
#     start_time = time.time()
#     DFT(x)
#     end_time = time.time()
#     dft_time.append(end_time - start_time)
#
# plt.figure(figsize=(10, 5))
# plt.plot(input, dft_time, marker='o')
# plt.title('DFT Time complexity')
# plt.xlabel('N')
# plt.ylabel('Time(s)')
# plt.grid(True)
# plt.show()

# FFT

# input = 2**np.array(list(range(1, 23)))
# fft_time = []
#
# for size in input:
#     x = np.random.random(size)
#     start_time = time.time()
#     FFT(x)
#     end_time = time.time()
#     fft_time.append(end_time - start_time)
#
# plt.figure(figsize=(10, 5))
# plt.plot(input, fft_time, marker='o')
# plt.title('FFT Time complexity')
# plt.xlabel('N')
# plt.ylabel('Time(s)')
# plt.grid(True)
# plt.show()

# FFT vs DFT

input = 2 ** np.array(list(range(1, 14)))

dft_time = []
fft_time = []

# 각 입력 크기에 대해 DFT와 FFT 실행 시간 측정
for size in input:
    x = np.random.random(size)

    start_time = time.time()
    DFT(x)
    dft_time.append(time.time() - start_time)

    start_time = time.time()
    FFT(x)
    fft_time.append(time.time() - start_time)

plt.figure(figsize=(10, 5))
plt.plot(input, dft_time, marker='o', label='DFT')
plt.plot(input, fft_time, marker='x', label='FFT')
plt.title('FT Time Complexity')
plt.xlabel('N')
plt.ylabel('Time (s)')
plt.legend()
plt.grid(True)
plt.show()



