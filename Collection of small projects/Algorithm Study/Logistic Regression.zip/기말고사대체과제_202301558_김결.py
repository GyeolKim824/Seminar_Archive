import numpy as np
import matplotlib.pyplot as plt
# from mpl_toolkits.mplot3d import Axes3D

# 시그모이드(로지스틱)함수
def sigmoid(z):
    return 1 / (1 + np.exp(-z))

# 오즈
def odds(p):
    return p / (1-p)

# 독립변수들 정리
X = np.array([
    [20, 80, 0],
    [0, 0, 0],
    [10, 50, 0],
    [30, 40, 0],
    [10, 100, 0],
    [30, 100, 0],
    [50, 100, 1],
    [10, 0, 1],
    [20, 80, 0],
    [10, 0, 0],
    [10, 80, 0],
    [50, 100, 1],
    [15, 40, 0],
    [15, 100, 1],
    [20, 0, 1],
    [30, 80, 0],
    [20, 50, 0],
    [10, 0, 0],
    [40, 100, 0]
])

# 종속변수들 정리
y = np.array([0, 0, 0, 1, 1, 1, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 0, 0, 1])

def guess_my_score(x, b0, b1, b2, b3):
    z = b0 + b1 * x[0] + b2 * x[1] + b3 * x[2]
    p = sigmoid(z)
    return p, "응" if p >= 0.5 else "아니"
# 비용
def costfun(x, y, b0, b1, b2, b3):
    m = len(y)
    z = b0 + b2 * x[:, 0]+ b2 * x[:, 1] + b3 * x[:, 2]
    s = sigmoid(z)
    cost = (-1 / m) * np.sum(y * np.log(s) + (1 - y) * np.log(1 - s))
    return cost


def gradient_descent(x, y, learning=0.0005, iterations=1000, ha0=[], ha1=[], ha2=[], ha3=[], hy=[]):
    m = len(y)
    # b들을 랜덤값으로 넣어주기
    b0 = np.random.randn()
    b1 = np.random.randn()
    b2 = np.random.randn()
    b3 = np.random.randn()

    ha0.append(b0)
    ha1.append(b1)
    ha2.append(b2)
    ha3.append(b3)
    hy.append(costfun(x, y, b0, b1, b2, b3))

    for i in range(iterations):     # 1000번동안
        # 들어온 x에서 항목별로 뽑아서 선형결합 z
        z = b0 + b1 * x[:, 0] + b2 * x[:, 1] + b3 * x[:, 2]
        # 시그모이드에 z 넣기
        h = sigmoid(z)
        # 각각 기울기 (s-y)*x / m
        gradient_a0 = np.sum(h - y) / m
        gradient_a1 = np.sum((h - y) * x[:, 0]) / m
        gradient_a2 = np.sum((h - y) * x[:, 1]) / m
        gradient_a3 = np.sum((h - y) * x[:, 2]) / m

        # learning 값을 이용해서 b 업데이트
        b0 = b0 - learning * gradient_a0
        b1 = b1 - learning * gradient_a1
        b2 = b2 - learning * gradient_a2
        b3 = b3 - learning * gradient_a3

        # 코스트 계산, b 새로 저장
        cost = costfun(x, y, b0, b1, b2, b3)
        ha0.append(b0)
        ha1.append(b1)
        ha2.append(b2)
        ha3.append(b3)
        hy.append(cost)

    return b0, b1, b2, b3, ha0, ha1, ha2, ha3, hy

b0, b1, b2, b3, ha0, ha1, ha2, ha3, hy = gradient_descent(X, y)


x = np.array([float(input("얼마나 공부했어?: ")),
                      float(input("얼마나 힘들었어?: ")),
                      float(input("예습은 했어?: "))])

p, a_plus = guess_my_score(x, b0, b1, b2, b3)
print(f"확률: {p*100:f}%, 에이쁠?: {a_plus}")

# 계수들
# print(b0, b1, b2, b3)
#
# # 비용 함수
# plt.plot(hy)
# plt.xlabel('Iterations')
# plt.ylabel('Cost')
# plt.title('Cost Function')
# plt.grid(True)
# plt.show()


# b0 = -100
# b1 = 1
# b2 = 1
# b3 = 0

# x0, x1 값 범위 설정
# x0 = np.linspace(0, 100, 100)
# x1 = np.linspace(0, 100, 100)
# x0, x1 = np.meshgrid(x0, x1)
#
# z = b0 + b1 * x0 + b2 * x1
#
# Ey = sigmoid(z)
#
# fig = plt.figure(figsize=(10, 7))
# ax = fig.add_subplot(111, projection='3d')
# ax.plot_surface(x0, x1, Ey)
#
# ax.set_xlabel('x0')
# ax.set_ylabel('x1')
# ax.set_zlabel('y')
#
# plt.show()

